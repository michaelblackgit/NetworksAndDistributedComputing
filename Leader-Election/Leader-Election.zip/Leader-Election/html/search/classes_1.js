var searchData=
[
  ['nearest_5fneighbor_5ft',['nearest_neighbor_t',['../structnearest__neighbor__t.html',1,'']]]
];
