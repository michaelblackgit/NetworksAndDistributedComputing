var searchData=
[
  ['send_5felection',['send_election',['../struct_u_s_e_r_d_a_t_a.html#a4810020dbab38cc0516951ed762b5028',1,'USERDATA']]],
  ['state',['state',['../structnearest__neighbor__t.html#a6888323805aed698b5485548a6b17390',1,'nearest_neighbor_t::state()'],['../struct_u_s_e_r_d_a_t_a.html#aeed785c38cdfd9bc4356b47287f4cc33',1,'USERDATA::state()']]]
];
