var searchData=
[
  ['leader',['LEADER',['../ring_8h.html#abfa4129c01696b7e625c9f18fc2dfd6d',1,'ring.h']]],
  ['leave',['LEAVE',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470ae09e07839103de682cb13fa773793fc0',1,'ring.h']]],
  ['left',['LEFT',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1adb45120aafd37a973140edee24708065',1,'ring.h']]],
  ['left_5fid',['left_id',['../structnearest__neighbor__t.html#a984e7811a540a37d34dafd2644e0dc88',1,'nearest_neighbor_t::left_id()'],['../ring_8h.html#add101440435d6b76ecf18896c9eefc80',1,'LEFT_ID():&#160;ring.h']]],
  ['loop',['loop',['../ring_8c.html#afe461d27b9c48d5921c00d521181f12f',1,'ring.c']]]
];
