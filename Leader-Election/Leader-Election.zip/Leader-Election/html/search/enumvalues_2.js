var searchData=
[
  ['elected',['ELECTED',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470a28252a8ef1bc62b3a73aab747f980663',1,'ring.h']]],
  ['election',['ELECTION',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470adca3ea7fa09ef8a260d98e3f62b72636',1,'ring.h']]]
];
