var searchData=
[
  ['blue',['blue',['../struct_u_s_e_r_d_a_t_a.html#aa5fb7ae10345095126fa610507cddb0c',1,'USERDATA']]]
];
