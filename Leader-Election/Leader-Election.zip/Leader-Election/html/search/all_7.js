var searchData=
[
  ['id',['id',['../structnearest__neighbor__t.html#a5066463b41970a48266d868b25c9c211',1,'nearest_neighbor_t::id()'],['../ring_8h.html#a77ceac8d6af195fe72f95f6afd87c45e',1,'ID():&#160;ring.h']]],
  ['in_5finterval',['in_interval',['../ring_8c.html#a764ba1034860f888b777fdf475143667',1,'ring.c']]],
  ['is_5fleader',['is_leader',['../struct_u_s_e_r_d_a_t_a.html#abe929e6fb03957843bcb3a8b4030f63a',1,'USERDATA']]],
  ['is_5fstabilized',['is_stabilized',['../ring_8c.html#a77db9a24f35da1c9278ccd2d15720552',1,'ring.c']]]
];
