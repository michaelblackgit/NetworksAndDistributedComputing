var searchData=
[
  ['autonomous',['AUTONOMOUS',['../ring_8h.html#a69b20b1a04c8e4cf3b72851b966259eca15984d1e548813ca0e54895a2322b54b',1,'ring.h']]]
];
