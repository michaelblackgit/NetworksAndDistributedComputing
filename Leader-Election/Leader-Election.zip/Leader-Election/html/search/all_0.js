var searchData=
[
  ['active',['ACTIVE',['../ring_8h.html#a3a6d3cd70078e6046471ec528a09cd19',1,'ring.h']]],
  ['are_5fall_5fcooperative',['are_all_cooperative',['../ring_8c.html#acc148f4ab3c9d5f09b3db2a3077b3fc1',1,'ring.c']]],
  ['autonomous',['AUTONOMOUS',['../ring_8h.html#a69b20b1a04c8e4cf3b72851b966259eca15984d1e548813ca0e54895a2322b54b',1,'ring.h']]]
];
