var searchData=
[
  ['null_5fmsg',['NULL_MSG',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470a2e269dfbf70bb56eddcf95b39bf94d2e',1,'ring.h']]]
];
