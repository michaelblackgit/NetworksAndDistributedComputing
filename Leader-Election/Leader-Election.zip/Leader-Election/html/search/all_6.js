var searchData=
[
  ['get_5fnearest_5ftwo_5fneighbors',['get_nearest_two_neighbors',['../ring_8c.html#af19fc3162e19356dfdd8d2d04fb98ad9',1,'ring.c']]],
  ['green',['green',['../struct_u_s_e_r_d_a_t_a.html#a25eeb02dc0734abc99a841f18ffddc28',1,'USERDATA']]]
];
