var searchData=
[
  ['share',['SHARE',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470a3754861e8c074fb088a2ed4f64786268',1,'ring.h']]],
  ['stop',['STOP',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1a679ee5320d66c8322e310daeb2ee99b8',1,'ring.h']]]
];
