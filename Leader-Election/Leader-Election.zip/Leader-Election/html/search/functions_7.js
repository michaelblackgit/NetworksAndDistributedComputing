var searchData=
[
  ['recv_5felection',['recv_election',['../ring_8c.html#ac178becefc5a6cb069d7204976ae4506',1,'ring.c']]],
  ['recv_5fjoining',['recv_joining',['../ring_8c.html#a27b20f1b26960043194f20584b81f3c9',1,'ring.c']]],
  ['recv_5fsharing',['recv_sharing',['../ring_8c.html#ad8d6e8bd005b92febac972bac5171128',1,'ring.c']]]
];
