var searchData=
[
  ['distance',['distance',['../structnearest__neighbor__t.html#ae89e1b1120b55df59443ab6f743d95d9',1,'nearest_neighbor_t']]]
];
