var searchData=
[
  ['receiver',['RECEIVER',['../ring_8h.html#a455948b8bd5f5ce920899ae1013c4b4c',1,'ring.h']]],
  ['right_5fid',['RIGHT_ID',['../ring_8h.html#af23fdd273a208806b49daf7499e0d9f2',1,'ring.h']]]
];
