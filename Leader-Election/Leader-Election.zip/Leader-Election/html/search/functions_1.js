var searchData=
[
  ['exists_5fnearest_5fneighbor',['exists_nearest_neighbor',['../ring_8c.html#a421bd0c8e972c872a4c101c7fe2776db',1,'ring.c']]]
];
