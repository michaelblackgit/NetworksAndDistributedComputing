var searchData=
[
  ['sender',['SENDER',['../ring_8h.html#afe3a5d0081166bd5e1d8c9ea00db83e5',1,'ring.h']]],
  ['sharing_5ftime',['SHARING_TIME',['../ring_8h.html#a8eb91fb063c5d18e88bb6c778f7de643',1,'ring.h']]],
  ['state',['STATE',['../ring_8h.html#aacd2cf60f504e45efada9aec028ee3cd',1,'ring.h']]]
];
