var searchData=
[
  ['message_5ftype',['message_type',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470',1,'ring.h']]],
  ['motion_5ft',['motion_t',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1',1,'ring.h']]]
];
