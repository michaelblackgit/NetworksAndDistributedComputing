var searchData=
[
  ['cooperative',['COOPERATIVE',['../ring_8h.html#a69b20b1a04c8e4cf3b72851b966259eca30a2b67f2e32e72b60a647b7c019bd21',1,'ring.h']]]
];
