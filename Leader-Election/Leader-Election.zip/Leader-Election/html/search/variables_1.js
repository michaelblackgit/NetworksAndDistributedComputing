var searchData=
[
  ['cur_5fmotion',['cur_motion',['../struct_u_s_e_r_d_a_t_a.html#a776accb60751dfaaef71a780aa26565e',1,'USERDATA']]]
];
