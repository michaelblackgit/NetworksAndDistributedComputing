var searchData=
[
  ['cooperative',['COOPERATIVE',['../ring_8h.html#a69b20b1a04c8e4cf3b72851b966259eca30a2b67f2e32e72b60a647b7c019bd21',1,'ring.h']]],
  ['cur_5fmotion',['cur_motion',['../struct_u_s_e_r_d_a_t_a.html#a776accb60751dfaaef71a780aa26565e',1,'USERDATA']]]
];
