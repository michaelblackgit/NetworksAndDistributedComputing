var searchData=
[
  ['prepare_5fmessage',['prepare_message',['../ring_8c.html#ad1b5e8bdcafee199c2a5e0f255ac6585',1,'ring.c']]]
];
