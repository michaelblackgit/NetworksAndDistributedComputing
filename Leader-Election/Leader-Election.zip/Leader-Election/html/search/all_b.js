var searchData=
[
  ['nearest_5fneighbor_5ft',['nearest_neighbor_t',['../structnearest__neighbor__t.html',1,'']]],
  ['nearest_5fneighbors',['nearest_neighbors',['../struct_u_s_e_r_d_a_t_a.html#a832531c1f98fb79baf05dc6c9b5e40db',1,'USERDATA']]],
  ['next_5fshare_5fsending',['next_share_sending',['../struct_u_s_e_r_d_a_t_a.html#ae0685229eff329f48d65545f220fcfa8',1,'USERDATA']]],
  ['now',['now',['../struct_u_s_e_r_d_a_t_a.html#afcf3cc6c2f239e554bc02618ab358e77',1,'USERDATA']]],
  ['null_5fmsg',['NULL_MSG',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470a2e269dfbf70bb56eddcf95b39bf94d2e',1,'ring.h']]],
  ['num',['num',['../structnearest__neighbor__t.html#a2281e5dac12c7cd3c84d4902077d84c9',1,'nearest_neighbor_t']]],
  ['num_5fcooperative',['num_cooperative',['../structnearest__neighbor__t.html#a1067d90cd055d66e9657dfa1dfe76202',1,'nearest_neighbor_t']]],
  ['num_5fneighbors',['num_neighbors',['../struct_u_s_e_r_d_a_t_a.html#aaa17d68b98a3923b1e67af7212d0ac52',1,'USERDATA']]]
];
