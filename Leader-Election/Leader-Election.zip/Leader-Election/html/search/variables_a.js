var searchData=
[
  ['time',['time',['../structmotion__time__t.html#ae85eb141921db45d916cc792306475c9',1,'motion_time_t']]],
  ['time_5factive',['time_active',['../struct_u_s_e_r_d_a_t_a.html#ac7d7ea7ea2501228ad03e408fd68c1cf',1,'USERDATA']]]
];
