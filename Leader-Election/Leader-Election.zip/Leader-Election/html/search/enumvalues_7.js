var searchData=
[
  ['right',['RIGHT',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1aec8379af7490bb9eaaf579cf17876f38',1,'ring.h']]]
];
