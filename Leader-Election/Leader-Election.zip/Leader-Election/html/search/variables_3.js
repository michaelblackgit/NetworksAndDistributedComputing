var searchData=
[
  ['green',['green',['../struct_u_s_e_r_d_a_t_a.html#a25eeb02dc0734abc99a841f18ffddc28',1,'USERDATA']]]
];
