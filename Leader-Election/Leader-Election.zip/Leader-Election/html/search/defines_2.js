var searchData=
[
  ['leader',['LEADER',['../ring_8h.html#abfa4129c01696b7e625c9f18fc2dfd6d',1,'ring.h']]],
  ['left_5fid',['LEFT_ID',['../ring_8h.html#add101440435d6b76ecf18896c9eefc80',1,'ring.h']]]
];
