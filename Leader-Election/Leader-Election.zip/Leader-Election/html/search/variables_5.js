var searchData=
[
  ['left_5fid',['left_id',['../structnearest__neighbor__t.html#a984e7811a540a37d34dafd2644e0dc88',1,'nearest_neighbor_t']]]
];
