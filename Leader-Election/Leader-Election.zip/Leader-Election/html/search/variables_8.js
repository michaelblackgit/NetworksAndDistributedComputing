var searchData=
[
  ['red',['red',['../struct_u_s_e_r_d_a_t_a.html#a489b2c5c4ef2024d3b9b1972850facee',1,'USERDATA']]],
  ['right_5fid',['right_id',['../structnearest__neighbor__t.html#af02c019de642bf55bdf9a4126fbcf834',1,'nearest_neighbor_t']]]
];
