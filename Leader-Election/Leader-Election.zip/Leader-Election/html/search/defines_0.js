var searchData=
[
  ['active',['ACTIVE',['../ring_8h.html#a3a6d3cd70078e6046471ec528a09cd19',1,'ring.h']]]
];
