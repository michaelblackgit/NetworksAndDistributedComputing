var searchData=
[
  ['userdata',['USERDATA',['../struct_u_s_e_r_d_a_t_a.html',1,'']]]
];
