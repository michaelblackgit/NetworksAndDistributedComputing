var searchData=
[
  ['forward',['FORWARD',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1aa26736999186daf8146f809e863712a1',1,'ring.h']]]
];
