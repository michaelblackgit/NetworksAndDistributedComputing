var searchData=
[
  ['receiver',['RECEIVER',['../ring_8h.html#a455948b8bd5f5ce920899ae1013c4b4c',1,'ring.h']]],
  ['recv_5felection',['recv_election',['../ring_8c.html#ac178becefc5a6cb069d7204976ae4506',1,'ring.c']]],
  ['recv_5fjoining',['recv_joining',['../ring_8c.html#a27b20f1b26960043194f20584b81f3c9',1,'ring.c']]],
  ['recv_5fsharing',['recv_sharing',['../ring_8c.html#ad8d6e8bd005b92febac972bac5171128',1,'ring.c']]],
  ['red',['red',['../struct_u_s_e_r_d_a_t_a.html#a489b2c5c4ef2024d3b9b1972850facee',1,'USERDATA']]],
  ['right',['RIGHT',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1aec8379af7490bb9eaaf579cf17876f38',1,'ring.h']]],
  ['right_5fid',['right_id',['../structnearest__neighbor__t.html#af02c019de642bf55bdf9a4126fbcf834',1,'nearest_neighbor_t::right_id()'],['../ring_8h.html#af23fdd273a208806b49daf7499e0d9f2',1,'RIGHT_ID():&#160;ring.h']]],
  ['ring_2ec',['ring.c',['../ring_8c.html',1,'']]],
  ['ring_2eh',['ring.h',['../ring_8h.html',1,'']]],
  ['robot_5fstate',['robot_state',['../ring_8h.html#a69b20b1a04c8e4cf3b72851b966259ec',1,'ring.h']]]
];
