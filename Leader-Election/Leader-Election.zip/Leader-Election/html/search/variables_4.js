var searchData=
[
  ['id',['id',['../structnearest__neighbor__t.html#a5066463b41970a48266d868b25c9c211',1,'nearest_neighbor_t']]],
  ['is_5fleader',['is_leader',['../struct_u_s_e_r_d_a_t_a.html#abe929e6fb03957843bcb3a8b4030f63a',1,'USERDATA']]]
];
