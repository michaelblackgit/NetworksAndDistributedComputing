var searchData=
[
  ['id',['ID',['../ring_8h.html#a77ceac8d6af195fe72f95f6afd87c45e',1,'ring.h']]]
];
