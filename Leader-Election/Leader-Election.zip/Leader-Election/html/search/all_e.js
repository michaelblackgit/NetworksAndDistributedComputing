var searchData=
[
  ['send_5felection',['send_election',['../struct_u_s_e_r_d_a_t_a.html#a4810020dbab38cc0516951ed762b5028',1,'USERDATA::send_election()'],['../ring_8c.html#ab9082108a5add8649dfe4d65c7d7b676',1,'send_election():&#160;ring.c']]],
  ['send_5fjoining',['send_joining',['../ring_8c.html#a1695dcc0c6a920317d739886e3266093',1,'ring.c']]],
  ['send_5fsharing',['send_sharing',['../ring_8c.html#a95a8f45823e9116b153d0b1f7eaa6201',1,'ring.c']]],
  ['sender',['SENDER',['../ring_8h.html#afe3a5d0081166bd5e1d8c9ea00db83e5',1,'ring.h']]],
  ['set_5fmotion',['set_motion',['../ring_8c.html#a88524e838112e1905cc3f74b0735ae71',1,'ring.c']]],
  ['setup',['setup',['../ring_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'ring.c']]],
  ['share',['SHARE',['../ring_8h.html#a4e0a9e26bf11796d8ca091cb6b3ce470a3754861e8c074fb088a2ed4f64786268',1,'ring.h']]],
  ['sharing_5ftime',['SHARING_TIME',['../ring_8h.html#a8eb91fb063c5d18e88bb6c778f7de643',1,'ring.h']]],
  ['smooth_5fset_5fmotors',['smooth_set_motors',['../ring_8c.html#a540b8ce2367b2cf4b32c8b8c7e9642fc',1,'ring.c']]],
  ['state',['state',['../structnearest__neighbor__t.html#a6888323805aed698b5485548a6b17390',1,'nearest_neighbor_t::state()'],['../struct_u_s_e_r_d_a_t_a.html#aeed785c38cdfd9bc4356b47287f4cc33',1,'USERDATA::state()'],['../ring_8h.html#aacd2cf60f504e45efada9aec028ee3cd',1,'STATE():&#160;ring.h']]],
  ['stop',['STOP',['../ring_8h.html#af714dce6622a529fd1e432cb0dbfe0a1a679ee5320d66c8322e310daeb2ee99b8',1,'ring.h']]]
];
