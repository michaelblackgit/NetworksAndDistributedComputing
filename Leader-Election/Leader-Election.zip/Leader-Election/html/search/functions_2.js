var searchData=
[
  ['get_5fnearest_5ftwo_5fneighbors',['get_nearest_two_neighbors',['../ring_8c.html#af19fc3162e19356dfdd8d2d04fb98ad9',1,'ring.c']]]
];
