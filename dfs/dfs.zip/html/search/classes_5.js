var searchData=
[
  ['result',['Result',['../class_result.html',1,'']]]
];
